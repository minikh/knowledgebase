https://habrahabr.ru/post/225189/
