package ru.gazprombank.card.config;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;
import info.jerrinot.subzero.SubZero;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;

@Configuration
public class HazelcastConfig {

    @Value("${hazelcastUrl}")
    private String hazelcastUrl;

    @Bean
    public HazelcastInstance hazelcastInstance() {
        ClientConfig config = new ClientConfig();
        SubZero.useAsGlobalSerializer(config);
        config.getNetworkConfig().setAddresses(Collections.singletonList(hazelcastUrl));

        return HazelcastClient.newHazelcastClient(config);
    }

}
