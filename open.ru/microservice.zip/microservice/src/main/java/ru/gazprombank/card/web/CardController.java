package ru.gazprombank.card.web;

import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import ru.gazprombank.card.service.CardDto;
import ru.gazprombank.card.service.CardService;
import ru.gazprombank.card.web.util.JsonItem;
import ru.gazprombank.card.web.util.JsonItemBuilder;

import java.util.List;
import java.util.Optional;

import static ru.gazprombank.card.web.util.JsonItemBuilder.success;

@RestController
@RequestMapping("api/card")
public class CardController {

    private final CardService cardService;

    @Autowired
    public CardController(CardService cardService) {
        this.cardService = cardService;
    }

    @ApiOperation(value = "Получить все карты")
    @RequestMapping(method = RequestMethod.GET)
    public JsonItem<List<CardDto>> getCards() {
        return success(cardService.getCards());
    }

    @ApiOperation(value = "Получить карту по id")
    @RequestMapping(value = "{id}", method = RequestMethod.GET)
    public JsonItem<CardDto> getCard(@PathVariable Long id) {
        Optional<CardDto> card = cardService.getCard(id);
        return card
                .map(JsonItemBuilder::success)
                .orElseGet(JsonItemBuilder::error);
    }

    @ApiOperation(value = "Добавить новую карту")
    @RequestMapping(method = RequestMethod.POST)
    public JsonItem<CardDto> newCard(@RequestBody CardDto newCard) {
        return success(cardService.newCard(newCard));
    }

    @ApiOperation(value = "Удалить карту")
    @RequestMapping(value = "{id}", method = RequestMethod.DELETE)
    public JsonItem deleteCard(@PathVariable Long id) {
        cardService.deleteCard(id);
        return success();
    }
}
