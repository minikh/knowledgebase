package ru.gazprombank.card.service;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class CardDto {
    private Long id;
    @ApiModelProperty(value = "id карты", required = true)
    private String cardId;
}
