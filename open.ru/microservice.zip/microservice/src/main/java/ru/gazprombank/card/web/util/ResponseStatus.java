package ru.gazprombank.card.web.util;

public enum ResponseStatus {
    SUCCESS,
    MESSAGE,
    ERROR
}
