package ru.gazprombank.card.web.util;

public class JsonItemBuilder {

    private final static String VERSION = "0.1";

    public static <T> JsonItem<T> success(T result) {
        JsonItem<T> jsonItem = new JsonItem<>();
        jsonItem.setResult(result);
        jsonItem.setStatus(ResponseStatus.SUCCESS);
        jsonItem.setVersion("0.1");

        return jsonItem;
    }

    public static JsonItem success() {
        JsonItem jsonItem = new JsonItem();
        jsonItem.setStatus(ResponseStatus.SUCCESS);
        jsonItem.setVersion(VERSION);

        return jsonItem;
    }

    public static <T> JsonItem<T> message() {
        JsonItem<T> jsonItem = new JsonItem<>();
        jsonItem.setStatus(ResponseStatus.MESSAGE);
        jsonItem.setVersion(VERSION);

        return jsonItem;
    }

    public static <T> JsonItem<T> error() {
        JsonItem<T> jsonItem = new JsonItem<>();
        jsonItem.setStatus(ResponseStatus.ERROR);
        jsonItem.setVersion(VERSION);

        return jsonItem;
    }
}