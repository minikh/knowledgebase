package ru.gazprombank.card.service;

import ma.glasnost.orika.MapperFacade;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.gazprombank.card.jpa.CardEntity;
import ru.gazprombank.card.jpa.CardRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CardService {

    private static final Logger LOG = LoggerFactory.getLogger(CardService.class);

    private final CardRepository cardRepository;
    private final MapperFacade mapper;

    @Autowired
    public CardService(CardRepository cardRepository, MapperFacade mapper) {
        this.cardRepository = cardRepository;
        this.mapper = mapper;
    }

    public List<CardDto> getCards() {
        List<CardEntity> cards = cardRepository.findAll();

        return cards.stream()
                .map(card -> mapper.map(card, CardDto.class))
                .collect(Collectors.toList());
    }

    public Optional<CardDto> getCard(Long id) {
        Optional<CardEntity> card = cardRepository.findById(id);
        return card.map(cardEntity -> mapper.map(cardEntity, CardDto.class));
    }

    @NotNull
    public CardDto newCard(CardDto newCard) {
        CardEntity savedCard = cardRepository.save(mapper.map(newCard, CardEntity.class));
        return mapper.map(savedCard, CardDto.class);
    }

    public void deleteCard(Long cardId) {
        cardRepository.deleteById(cardId);
    }
}
