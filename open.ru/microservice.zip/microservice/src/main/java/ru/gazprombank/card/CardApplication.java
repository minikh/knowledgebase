package ru.gazprombank.card;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import ru.gazprombank.card.config.HazelcastConfig;

@SpringBootApplication
public class CardApplication {

    private final HazelcastConfig hazelcastConfig;

    private static final Logger log = LoggerFactory.getLogger(CardApplication.class);

    @Autowired
    public CardApplication(HazelcastConfig hazelcastConfig) {
        this.hazelcastConfig = hazelcastConfig;
    }

    public static void main(String[] args) {
        SpringApplication.run(CardApplication.class, args);
    }

//    @Bean
//    public CommandLineRunner demo(CardRepository repository) {
//        IMap<Object, Object> cards = hazelcastConfig.hazelcastInstance().getMap("cards");
//        cards.clear();
//
//        return (args) -> {
//            CardEntity cardEntity = new CardEntity();
//            cardEntity.setCardId(new Date().toString());
//
//            log.info("-------------------------------");
//            for (CardEntity card : repository.findAll()) {
//                cards.put(card.getId(), card);
//            }
//
//            cards.forEach((k, v) -> System.out.println(v));
//        };
//    }
}

