--liquibase formatted sql

--changeset minikh:1
create table card_service.card
(
	id serial not null
		constraint card_pkey
			primary key,
	card_id varchar(50)
);

